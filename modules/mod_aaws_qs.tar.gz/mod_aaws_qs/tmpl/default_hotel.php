<?php

echo 'Hotels';
