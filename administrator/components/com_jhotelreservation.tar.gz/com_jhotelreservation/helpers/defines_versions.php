
			  	 	 
			  		 	<?php
			   	    	/*------------------------------------------------------------------------
			   	    	# JHotelReservation
			   	    	# author CMSJunkie
			   	    	# copyright Copyright (C) 2013 cmsjunkie.com. All Rights Reserved.
			   	    	# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
			   	    	# Websites: http://www.cmsjunkie.com
			   	    	# Technical Support:  Forum - http://www.cmsjunkie.com/forum/hotel_reservation/?p=1
			   	    	-------------------------------------------------------------------------*/
					   	if(!defined( 'STARTER_VERSION'))
					  	 	define('STARTER_VERSION', 0 );
					   	if(!defined( 'PROFESSIONAL_VERSION'))
					   		define('PROFESSIONAL_VERSION', 1 );
					   	if(!defined( 'PORTAL_VERSION'))
					   		define('PORTAL_VERSION', 0 );
					   	if(!defined( 'ENABLE_SINGLE_HOTEL'))
					   		define('ENABLE_SINGLE_HOTEL', 0 );
			   			?>
			   	     
			 