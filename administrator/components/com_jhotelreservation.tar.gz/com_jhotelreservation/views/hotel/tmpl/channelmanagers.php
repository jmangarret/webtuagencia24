
				  	 	 
				  		 	<?php
				   	    	/*------------------------------------------------------------------------
				   	    	# JHotelReservation
				   	    	# author CMSJunkie
				   	    	# copyright Copyright (C) 2013 cmsjunkie.com. All Rights Reserved.
				   	    	# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
				   	    	# Websites: http://www.cmsjunkie.com
				   	    	# Technical Support:  Forum - http://www.cmsjunkie.com/forum/hotel_reservation/?p=1
				   	    	-------------------------------------------------------------------------*/
				   	    	defined('_JEXEC') or die('Restricted access');
				   			echo JText::_('LNG_FEATURE_AVAILABLE_IN_PORTAL',true);
				   			?>
				   	     
				   